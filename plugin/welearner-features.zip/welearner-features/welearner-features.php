<?php
/*
Plugin Name: Welearner Features
Plugin URI: http://wordpress.org/
Description: Assistance plugin for Welearner theme
Author: Pobon Paul
Version: 1.0
Author URI: https://www.facebook.com/kp.pobon/
text-domain: welearner-features
*/

// input custom postype

require_once(__DIR__.'/init.php');